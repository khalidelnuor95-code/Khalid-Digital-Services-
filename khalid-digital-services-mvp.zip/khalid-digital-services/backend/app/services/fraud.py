from sqlalchemy import select
from app.models.entities import Payment

# Transparent starter rules only. This is triage, not proof of fraud or bank settlement.
def assess_payment(db, payment: Payment) -> tuple[int, list[str]]:
    score, reasons = 0, []
    if payment.reference:
        duplicate = db.scalar(select(Payment).where(Payment.reference == payment.reference, Payment.id != payment.id))
        if duplicate:
            score += 85
            reasons.append("مرجع العملية مستخدم في عملية أخرى")
    else:
        score += 15
        reasons.append("لا يوجد رقم مرجعي للتحقق")
    if not payment.proof_text:
        score += 20
        reasons.append("لا توجد بيانات إثبات مرفقة")
    return min(score, 100), reasons
