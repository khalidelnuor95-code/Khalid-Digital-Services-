from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select, func
from app.core.db import get_db
from app.models.entities import Customer, Service, Order, Payment
from app.schemas.dto import CustomerIn, OrderIn, PaymentIn
from app.services.fraud import assess_payment

router = APIRouter()

@router.get("/health")
def health(): return {"status": "ok"}

@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db)):
    return {
        "customers": db.scalar(select(func.count()).select_from(Customer)) or 0,
        "orders": db.scalar(select(func.count()).select_from(Order)) or 0,
        "pending_orders": db.scalar(select(func.count()).select_from(Order).where(Order.status == "pending")) or 0,
        "payments_review": db.scalar(select(func.count()).select_from(Payment).where(Payment.status.in_(["submitted", "review"]))) or 0,
    }

@router.get("/services")
def list_services(db: Session = Depends(get_db)):
    return db.scalars(select(Service).order_by(Service.category, Service.name)).all()

@router.post("/customers")
def create_customer(payload: CustomerIn, db: Session = Depends(get_db)):
    if db.scalar(select(Customer).where(Customer.phone == payload.phone)):
        raise HTTPException(409, "رقم الهاتف مسجل مسبقاً")
    obj = Customer(**payload.model_dump()); db.add(obj); db.commit(); db.refresh(obj); return obj

@router.get("/customers")
def list_customers(db: Session = Depends(get_db)):
    return db.scalars(select(Customer).order_by(Customer.id.desc()).limit(100)).all()

@router.post("/orders")
def create_order(payload: OrderIn, db: Session = Depends(get_db)):
    if not db.get(Customer, payload.customer_id) or not db.get(Service, payload.service_id):
        raise HTTPException(404, "العميل أو الخدمة غير موجودة")
    obj = Order(**payload.model_dump()); db.add(obj); db.commit(); db.refresh(obj); return obj

@router.get("/orders")
def list_orders(db: Session = Depends(get_db)):
    return db.scalars(select(Order).order_by(Order.id.desc()).limit(100)).all()

@router.post("/payments")
def submit_payment(payload: PaymentIn, db: Session = Depends(get_db)):
    order = db.get(Order, payload.order_id)
    if not order: raise HTTPException(404, "الطلب غير موجود")
    if float(payload.amount) != float(order.amount):
        raise HTTPException(400, "المبلغ لا يطابق قيمة الطلب؛ راجع الطلب قبل الإرسال")
    obj = Payment(**payload.model_dump()); db.add(obj); db.flush()
    score, reasons = assess_payment(db, obj)
    obj.risk_score, obj.risk_reasons = score, "؛ ".join(reasons)
    obj.status = "review" if score >= 30 else "submitted"
    db.commit(); db.refresh(obj); return obj

@router.get("/payments")
def list_payments(db: Session = Depends(get_db)):
    return db.scalars(select(Payment).order_by(Payment.id.desc()).limit(100)).all()

@router.post("/payments/{payment_id}/approve")
def approve_payment(payment_id: int, db: Session = Depends(get_db)):
    payment = db.get(Payment, payment_id)
    if not payment: raise HTTPException(404, "الدفعة غير موجودة")
    # Admin-only authorization must be added before production deployment.
    payment.status = "approved"; db.commit(); db.refresh(payment); return payment
