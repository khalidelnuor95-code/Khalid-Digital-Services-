from pydantic import BaseModel, Field
from typing import Literal

class CustomerIn(BaseModel):
    name: str = Field(min_length=2, max_length=160)
    phone: str = Field(min_length=5, max_length=40)
    email: str | None = None

class OrderIn(BaseModel):
    customer_id: int
    service_id: int
    quantity: int = Field(default=1, ge=1, le=1000)
    amount: float = Field(gt=0)
    currency: str = "SDG"
    notes: str | None = None

class PaymentIn(BaseModel):
    order_id: int
    method: Literal["bankak", "bank_transfer", "cash", "usdt", "other"]
    amount: float = Field(gt=0)
    currency: str = "SDG"
    reference: str | None = None
    proof_text: str | None = None
