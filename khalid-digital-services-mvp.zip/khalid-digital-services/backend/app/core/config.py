from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "Khalid Digital Services"
    database_url: str = "sqlite:///./dev.db"
    cors_origins: str = "http://localhost:3000"
    mikrotik_base_url: str = ""
    mikrotik_username: str = ""
    mikrotik_password: str = ""
    mikrotik_verify_tls: bool = True
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
