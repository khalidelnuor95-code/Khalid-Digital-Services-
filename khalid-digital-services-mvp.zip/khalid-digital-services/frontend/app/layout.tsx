import type { Metadata } from "next";
import "./style.css";
export const metadata: Metadata = { title: "Khalid Digital Services", description: "منصة الخدمات الرقمية الذكية" };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="ar" dir="rtl"><body>{children}</body></html>; }
