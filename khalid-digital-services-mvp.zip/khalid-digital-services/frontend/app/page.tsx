"use client";
import { useEffect, useState } from "react";
const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api/v1";
export default function Home() {
 const [stats,setStats] = useState({customers:0,orders:0,pending_orders:0,payments_review:0});
 const [services,setServices] = useState<any[]>([]); const [error,setError] = useState("");
 useEffect(()=>{ Promise.all([fetch(`${API}/dashboard`).then(r=>r.json()),fetch(`${API}/services`).then(r=>r.json())]).then(([s,v])=>{setStats(s);setServices(v)}).catch(()=>setError("تعذر الاتصال بالخادم. تحقق من تشغيل خدمات Docker.")); },[]);
 return <main className="shell"><header><div><p className="eyebrow">SMART DIGITAL SERVICES</p><h1>Khalid Digital Services</h1><p className="muted">منصة موحدة لإدارة الخدمات والطلبات والمدفوعات</p></div><span className="status">● النظام التجريبي</span></header>
 {error&&<p className="error">{error}</p>}<section className="stats">{[["العملاء",stats.customers],["كل الطلبات",stats.orders],["طلبات معلقة",stats.pending_orders],["مدفوعات للمراجعة",stats.payments_review]].map(([k,v])=><article className="stat" key={String(k)}><span>{k}</span><strong>{v}</strong></article>)}</section>
 <section><div className="section-head"><h2>كتالوج الخدمات</h2><span className="muted">الخدمات المفعّلة</span></div><div className="services">{services.length?services.map(s=><article className="service" key={s.id}><span className="service-icon">◇</span><div><b>{s.name}</b><p>{s.category}</p></div><span className="pill">{s.active?"نشطة":"متوقفة"}</span></article>):<article className="empty">سيظهر كتالوج الخدمات بعد إضافة الخدمات الأساسية إلى قاعدة البيانات.</article>}</div></section>
 <section className="notice"><b>مركز التحقق من المدفوعات</b><p>تُسجّل الإيصالات وتُفحص مؤشرات التكرار والمخاطر. لا يتم تأكيد الدفع اعتماداً على صورة إشعار وحدها؛ يلزم تحقق مصرفي موثوق أو اعتماد موظف مخوّل.</p></section>
 <footer>نسخة تأسيسية 0.1.0 · Ubuntu 24.04 · PostgreSQL · FastAPI · Next.js</footer></main>
}
